/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade.pkg5;

/**
 *
 * @author GAMER
 */

/*5. Monte um programa Java que mostre na tela em formato de tabela os
quartos ocupados e os desocupados. Considere que o hotel tem 4 andares e 3
quartos por andar. Primeiro, o usuário registrará os quartos ocupados,
informando para cada ocupação o número do apartamento (andar de 1 a 4 e
número de quarto de 1 a 3). O programa deverá questionar “Deseja informar
outra ocupação? (S/N)” e o usuário poderá informar quantos quartos quiser, até
que responda “N” a essa pergunta. Em seguida, o programa mostrará uma
tabela, em que o primeiro andar é o inferior e o último, o superior, marcando
com X o quarto ocupado.*/

 import java.util.Scanner;
public class Atividade5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
    /*Estou pesquisando mais sobre matrizes, vetores pois é uma dificuldade que tenho, então com o COURSE IA estou vendo mais sobre lógica
    de Programação, porque tem algumas estruturas e jeitos de escrever um código que eu não consigo entender o porquê foi feito assim e não assim.
        
        */
        int numAndares = 4;
        int numQuartosPorAndar = 3;

        char[][] quartos = new char[numAndares][numQuartosPorAndar];


        
        for (int andar = 0; andar < numAndares; andar++) {
            for (int quarto = 0; quarto < numQuartosPorAndar; quarto++) {
                quartos[andar][quarto] = ' ';
            }
        }


        
        Scanner scanner = new Scanner(System.in);


        
        boolean continuar = true;
        while (continuar) {
            System.out.print("Informe o andar (1 a 4): ");
            int andar = scanner.nextInt();
            System.out.print("Informe o número do quarto (1 a 3): ");
            int quarto = scanner.nextInt();

            if (andar >= 1 && andar <= numAndares && quarto >= 1 && quarto <= numQuartosPorAndar) {
                quartos[andar - 1][quarto - 1] = 'X';
            } else {
                System.out.println("Entrada inválida. Certifique-se de que o andar e o quarto estão dentro dos limites.");
            }

            System.out.print("Deseja informar outra ocupação? (S/N): ");
            String resposta = scanner.next();
            continuar = resposta.equalsIgnoreCase("S");
        }


        
        System.out.println("Tabela de ocupação dos quartos:");
        for (int andar = numAndares - 1; andar >= 0; andar--) {
            for (int quarto = 0; quarto < numQuartosPorAndar; quarto++) {
                System.out.print("Andar " + (andar + 1) + ", Quarto " + (quarto + 1) + ": [" + quartos[andar][quarto] + "]  ");
            }
            System.out.println();
        }
        

        
        scanner.close();
    }
}
