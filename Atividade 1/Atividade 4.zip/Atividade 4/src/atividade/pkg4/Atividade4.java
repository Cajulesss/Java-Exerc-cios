/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade.pkg4;

/**
 *
 * @author GAMER
 */

/*4. Monte um algoritmo em que o usuário poderá cadastrar e pesquisar hóspedes. O
algoritmo deve oferecer um menu com três opções ao usuário: 1- cadastrar; 2-
pesquisar; 3- sair. A opção “cadastrar” deve permitir que o usuário informe um
nome de hóspede, gravando-o em memória (máximo de 15 cadastros; caso atinja
essa quantidade, mostre “Máximo de cadastros atingido”). A opção “pesquisar” deve
permitir que o usuário informe um nome e, caso seja encontrado um nome
exatamente igual, mostre a mensagem “Hóspede (nome) foi encontrado no índice
(índice onde foi cadastrado)”. Se o nome não foi encontrado, mostre “Hóspede não
encontrado”. O algoritmo deve permitir que o usuário realize essas operações
repetidas vezes, até que use a opção “3”, que encerra o algoritmo.*/


import java.util.Scanner;

public class Atividade4 {

    public static void main(String[] args) {
        Scanner resp_usu = new Scanner(System.in);

        // Perguntar ao usuário o que ele deseja fazer
        System.out.println("Que operação deseja realizar?" + "\n" + "1-cadastrar" + "\n" + "2-pesquisar" + "\n" + "3-sair");

        // Condição se digitar (1-cadastrar), permitir informar nome do hóspede

        // Armazenar nome do usuário:
        String name_user;
        String cadastrar = "cadastrar";
        String pesquisar = "pesquisar";
        String close = "sair";

        String choose_usu = resp_usu.nextLine();

        boolean comparar_cadas = cadastrar.equalsIgnoreCase(choose_usu);
        boolean comparar_pesqui = pesquisar.equalsIgnoreCase(choose_usu);
        boolean comparar_close = close.equalsIgnoreCase(choose_usu);

        // Montar um vetor para armazenar os nomes dos hóspedes

        String[] nome_hospedes = new String[15];

        if (comparar_cadas) {
            for (int contador = 0; contador < nome_hospedes.length; contador++) {
                System.out.println("Digite o nome do hóspede " + (contador + 1) + ":");
                name_user = resp_usu.nextLine();
                nome_hospedes[contador] = name_user;
            }
        } else if (comparar_pesqui) {
            System.out.println("Digite o nome do hóspede que está procurando:");
            String pesquisar_hospede = resp_usu.nextLine();

            boolean encontrado = false;

            for (String nome : nome_hospedes) {
                if (pesquisar_hospede.equalsIgnoreCase(nome)) {
                    System.out.println("Hóspede: " + nome + "\n" + "Já cadastrado");
                    encontrado = true;
                    break;
                }
            }

            if (!encontrado) {
                System.out.println("Hóspede não encontrado.");
            }
            
            if(comparar_close == true){
            
                resp_usu.close();
            }
            
        }

        resp_usu.close();
    }
}