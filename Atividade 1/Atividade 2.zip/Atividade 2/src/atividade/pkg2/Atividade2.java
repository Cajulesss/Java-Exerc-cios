/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade.pkg2;

/**
 *
 * @author GAMER
 */
import java.util.Scanner;
public class Atividade2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*2. Escreva um programa Java que faça a troca de quartos entre dois hospedes. É
preciso que ele receba o nome de um cliente e sua idade; o cliente a princípio será
hospedado no quarto A. Depois, o programa deve receber o nome de outro cliente
e sua idade; se o cliente for mais jovem, ficará no quarto B, mas, se a idade deste
for maior que a do primeiro cliente, ele ficará no quarto A e o primeiro cliente ficará
no quarto B. Além disso, se a pessoa mais velha for idosa (com 60 anos ou mais),
terá desconto de 40%. O programa deve mostrar ao final o nome do cliente que
ficou no quarto A e o desconto, se houver, e o nome do cliente que ficou no quarto
B.*/
        Scanner resp_usuario = new Scanner(System.in);
        
        
        
        //Criação de um vetor para quartos A e B
        String[] Quartos = {"A", "B"};
        
        String[] Nome_Clientes = new String[Quartos.length];
        int [] Idade_clientes = new int [Quartos.length];
        
        
        for(int contador = 0; contador < Quartos.length;contador++){
            
            //Coletar o nome do cliente
            System.out.println("Nome do cliente para seu respectivo quarto: "+Quartos[contador]);
            String nome_cliente = resp_usuario.nextLine();
            
            
            Nome_Clientes[contador] = nome_cliente;
            
            
            //Coletar a idade do cliente
            System.out.println("Digite a idade do cliente para seu respectivo quarto: "+ Quartos[contador]);
            int idade_cliente = resp_usuario.nextInt();
            
            resp_usuario.nextLine();
            
            Idade_clientes[contador] = idade_cliente;
            
        }
            //Condição para troca de quartos
            
            if(Idade_clientes[0] > Idade_clientes[1]){
                System.out.println("Cliente: "+Nome_Clientes[0]+" Com idade de: " +Idade_clientes[0]+ " anos "+ "Alocado no quarto: " + Quartos[0]+ " com 40% de desconto!");
            }else{
                System.out.println("Cliente: "+Nome_Clientes[1]+" Com idade de: " +Idade_clientes[1]+ " anos "+ "Alocado no quarto: "+ Quartos[0]+ " com 40% de desconto!" );
            }
            
            
            if(Idade_clientes[0] < Idade_clientes[1] || Idade_clientes[1] < Idade_clientes[0]){
                System.out.println("Cliente: "+Nome_Clientes[0]+" Com idade de: " +Idade_clientes[0]+ " anos "+ "Alocado no quarto: " + Quartos[1]+ " Sem desconto!");
            }else{
                System.out.println("Cliente: "+Nome_Clientes[1]+" Com idade de: " +Idade_clientes[1]+ " anos "+ "Alocado no quarto: "+ Quartos[1]+ " Sem desconto!" );
            }
        
        
            //Printar as informações usando um novo vetor que inserirá as informações
            
            for(int contador = 0; contador < Quartos.length;contador++){
            System.out.println("No quarto: "+ Quartos[contador]+ " ficará respectivamente (Nome do cliente): "+Nome_Clientes[contador]+" com (idade): "+ Idade_clientes[contador]+ " anos" );
            
            
            }
            
            
        
                
        
    }
    
}
