/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade.pkg3;

/**
 *
 * @author GAMER
 */

/*3. Escreva um programa Java que receba o valor padrão de uma diária e em
seguida receba vários nomes de hóspedes e suas idades. Caso a idade do
hóspede seja menor de 4 anos, ele não paga hospedagem – nesses casos, é
preciso que seja mostrada na tela a mensagem “(Nome do hóspede) possui
gratuidade”. Hóspedes com mais de 80 anos pagam metade – então dever ser
mostrado na tela “(Nome do hóspede) paga meia”. O usuário informará hóspedes
até digitar a palavra “PARE”, que interrompe a entrada de dados. Ao fim, o
programa deve mostrar a quantidade de gratuidades, a quantidade de meias
hospedagens e o valor total, considerando todos os hóspedes informados.
*/

import java.util.Scanner;

public class Atividade3 {

    public static void main(String[] args) {
        Scanner resp_usuario = new Scanner(System.in);

        int Idade_gratuidade = 4;
        int Idade_meia = 60;

        int contador_gratuidade = 0;
        int contador_meia = 0;
        float total_valor_hospedagens = 0.0f; // Variável para somar todos os valores de hospedagens

        System.out.println("Bem-vindo ao Sistema do Hotel Blaper");

        while (true) {
            System.out.println("Digite seu nome (ou 'PARE' para encerrar):");
            String Nome_hospede = resp_usuario.nextLine();

            if (Nome_hospede.equalsIgnoreCase("PARE")) {
                break;
            }

            System.out.println("Digite sua idade:");
            int Idade_hospede = resp_usuario.nextInt();
            resp_usuario.nextLine(); // Consumir a quebra de linha pendente

            System.out.println("Digite o valor de sua diária:");
            float Valor_diaria = resp_usuario.nextFloat();
            resp_usuario.nextLine(); // Consumir a quebra de linha pendente

            if (Idade_hospede < Idade_gratuidade) {
                System.out.println(Nome_hospede + " possui gratuidade");
                contador_gratuidade++;
            } else if (Idade_hospede >= Idade_meia) {
                float valor_com_desconto = Valor_diaria * 0.5f;
                System.out.println(Nome_hospede + " paga meia, ficando no valor de: $" + valor_com_desconto);
                contador_meia++;
                total_valor_hospedagens += valor_com_desconto;
            } else {
                total_valor_hospedagens += Valor_diaria;
            }
        }

        System.out.println("Quantidade de gratuidades: " + contador_gratuidade);
        System.out.println("Quantidade de meias hospedagens: " + contador_meia);
        System.out.println("Valor total das hospedagens: $" + total_valor_hospedagens);

        resp_usuario.close();
    }
}