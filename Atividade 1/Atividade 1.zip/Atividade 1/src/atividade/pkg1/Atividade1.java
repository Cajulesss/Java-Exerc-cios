/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade.pkg1;

/**
 *
 * @author GAMER
 */

/*1. Relativo ao atendimento de eventos, o hotel necessita de uma funcionalidade
que indique qual de seus dois auditórios é o mais adequado para um evento. O
        auditório Alfa conta com 150 lugares e espaço para até 70 cadeiras adicionais. O
        auditório Beta conta com 350 lugares, sem espaço para mais cadeiras. Desenvolva
um programa Java que receba o número de convidados do evento e faça uma
verificação sobre esse número: se for maior que 350 ou menor que zero, deverá ser
mostrada a mensagem “Número de convidados inválido”. Se o valor informado é
válido, deverá ser mostrado na tela qual dos auditórios é o mais adequado. No caso
do auditório Alfa, será preciso calcular ainda quantas cadeiras adicionais serão
necessárias, observando o limite citado anteriormente.
*/

import java.util.Scanner;

public class Atividade1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Scanner resp_usuario = new Scanner(System.in);
      
        int Auditorio_alfa = 150;
        int Auditorio_beta = 350;
        int total_alfa_convidados = 220;

        System.out.println("BEM-VINDO AO SISTEMA DE AUDITÓRIOS DO HOTEL MIMITE!");
        System.out.println("Digite o número de convidados:");

        int Numero_convidados = resp_usuario.nextInt();
        
        
        //Falta os ifs e os elses de condições
        
        if(Numero_convidados > Auditorio_beta || Numero_convidados < 0){
            
            System.out.println("Numero de convidados digitado: "+ Numero_convidados + " Inválido" );
        }
        
        if(Numero_convidados > 0 && Numero_convidados < Auditorio_alfa){
        
            System.out.println("O auditório Alfa é o mais adequado sem acréscimo de cadeiras!");
        }else if(Numero_convidados > 150 && Numero_convidados <= total_alfa_convidados){
            
            System.out.println("Auditório Alfa com acréscimo de: "+ ( total_alfa_convidados - Numero_convidados )+" cadeiras");
            
        }if(Numero_convidados > total_alfa_convidados && Numero_convidados <= Auditorio_beta){
            
            System.out.println("O auditório Beta é o mais adequado sem acréscimo de cadeiras!");
        
        }
        
}
    }