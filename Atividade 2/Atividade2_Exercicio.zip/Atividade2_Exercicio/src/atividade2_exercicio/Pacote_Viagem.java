/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividade2_exercicio;

/**
 *
 * @author GAMER
 */
public class Pacote_Viagem {
    private String Tipo_tranporte;
    private double Valor_transporte;
    protected String Tipo_de_Quarto;
    private String Descricao_quarto;
    private double Valor_da_diaria;
    private String Destino_cliente;
    private long numero_dias_hospedagem;
    private double margem_lucro;
    private double taxas_adicionais;
    
    public String getTipo_transporte(){
   
        return this.Tipo_tranporte;
    
    }
    
    public double getValor_transporte(){
    
        return this.Valor_transporte;
    }
    
    
    public String getTipo_de_Quarto(){
    
        return this.Tipo_de_Quarto;
    }
    
    public String getDescricao_quarto(){
    
        return this.Descricao_quarto;
    }
    
    
    public double getValor_da_diaria(){
    
    return this.Valor_da_diaria;
    
    }
    
    public String getDestino_Cliente(){
    
        return this.Destino_cliente;
    }
    
    public long getnumero_dias_hospedagem(){
    
        return this.numero_dias_hospedagem;
    }
    
    public double getmargem_lucro(){
    
        return this.margem_lucro;
    }
    
    public double getTaxasAdicionais() {
        
    return this.taxas_adicionais;
}
    
    
    public void setValor_da_diaria(double valorDiaria) {
        
    this.Valor_da_diaria = valorDiaria;
    }
    
    public void setNumeroDiasHospedagem(long numeroDiasHospedagem) {
        
        this.numero_dias_hospedagem = numeroDiasHospedagem;
    }
    
    public void setmargem_lucro(double margem_lucro_hospedagem){
        
    this.margem_lucro = margem_lucro_hospedagem;
    }
    
    public void setTaxasAdicionais(double taxas_adicionais) {
        
    this.taxas_adicionais = taxas_adicionais;
}
    
    
    
    
    
    public double Total_hospedagem() {
        int dias_hospedagem = (int) getnumero_dias_hospedagem();
        double valor_Hospedagem = getValor_da_diaria();
    
    System.out.println("Dias de hospedagem: " + dias_hospedagem);
    System.out.println("Valor da diária: " + valor_Hospedagem);
    
        double Valor_total = dias_hospedagem * valor_Hospedagem;
    System.out.println("Valor total da hospedagem: " + Valor_total);
    
        return Valor_total;
}
    
    
    public double Calcula_Lucro() {
        double Valor_Hospedagem = Total_hospedagem();

        // Calcule o lucro com base na margem de lucro
        double lucro = Valor_Hospedagem * (margem_lucro / 100.0);
        
        System.out.println("Seu lucro é de: " + lucro + " R$");
        
        
        double totalPacote = Valor_Hospedagem + Valor_transporte + taxas_adicionais + lucro;
        System.out.println("O total do pacote é: " + totalPacote + " R$");
        
        return lucro;
    }
    
    
    
    public double Conversao_moeda(double taxaCambio){
    
        double Valor_Hospedagem = Total_hospedagem();
    double lucro = Valor_Hospedagem * (margem_lucro / 100.0);
    double totalPacote = Valor_Hospedagem + Valor_transporte + taxas_adicionais + lucro;
    
    // Realiza a conversão dos valores em dólar
    double valorEmDolar = totalPacote / taxaCambio;
    
    System.out.println("O total do pacote em dólar é: $" + valorEmDolar);
    
    return valorEmDolar;
    
        
    }
    
    
}
