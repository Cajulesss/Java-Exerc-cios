/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividade2_exercicio;

/**
 *
 * @author GAMER
 */
public class Transporte {
    //Atributos
    
    public String Tipo_tranporte;
    public double Valor_transporte;
    
    public void status_Transporte(){

    System.out.println("Valor do transporte escolhido: R$ "+this.Valor_transporte);

    }
}


