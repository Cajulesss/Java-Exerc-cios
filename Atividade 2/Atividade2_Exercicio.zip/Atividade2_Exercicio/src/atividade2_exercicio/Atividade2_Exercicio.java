/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package atividade2_exercicio;

/**
 *
 * @author GAMER
 */
import java.util.Scanner;

public class Atividade2_Exercicio {

    public static void main(String[] args) {
        Scanner resp_usuario = new Scanner(System.in);

        Transporte t1 = new Transporte();
        Hospedagem h1 = new Hospedagem();
        Pacote_Viagem pt = new Pacote_Viagem();

        System.out.println("Escolha qual transporte deseja usar:");
        String Tipo_do_Transporte = resp_usuario.nextLine();

        System.out.println("Digite o valor do transporte:");
        double Valor_do_Transporte = resp_usuario.nextDouble();
        resp_usuario.nextLine(); // Limpa a quebra de linha pendente

        t1.Valor_transporte = Valor_do_Transporte;
        t1.Tipo_tranporte = Tipo_do_Transporte;

        t1.status_Transporte();

        System.out.println("Digite o tipo de quarto que deseja hospedar-se:");
        String Tipo_Quarto = resp_usuario.nextLine();

        h1.Tipo_de_Quarto = Tipo_Quarto;

        h1.Status_Hospedagem();

        System.out.println("Digite o valor da sua diária: ");
        double valorDiaria = resp_usuario.nextDouble();
        resp_usuario.nextLine();

        pt.setValor_da_diaria(valorDiaria);

        System.out.println("Digite o número de dias que ficará hospedado(a): ");
        long numeroDiasHospedagem = resp_usuario.nextLong();
        resp_usuario.nextLine(); // Limpa a quebra de linha pendente

        pt.setNumeroDiasHospedagem(numeroDiasHospedagem);

        double valorTotalHospedagem = pt.Total_hospedagem();

        System.out.println("Valor total da hospedagem: R$ " + valorTotalHospedagem);

        System.out.println("Digite uma margem de lucro em percentual: ");
        double margemLucro = resp_usuario.nextDouble();

        // Defina a margem de lucro na classe Pacote_Viagem
        pt.setmargem_lucro(margemLucro);

        pt.setTaxasAdicionais(50.0);

        System.out.print("Nome do Cliente: ");
        String nomeCliente = resp_usuario.nextLine();


        System.out.print("Forma de Pagamento: ");
        String formaPagamento = resp_usuario.nextLine();


        Pacote_Viagem pacote = new Pacote_Viagem();
        pacote.setValor_da_diaria(valorDiaria);
        pacote.setNumeroDiasHospedagem(numeroDiasHospedagem);
        pacote.setmargem_lucro(margemLucro);
        pacote.setTaxasAdicionais(50.0);


        Venda venda = new Venda(nomeCliente, formaPagamento, pacote);

        System.out.print("Taxa de Câmbio (Reais por Dólar): ");
        double taxaCambio = resp_usuario.nextDouble();

        venda.realizarVenda(taxaCambio);
    }
}
/*Atividade 2
 
Contexto
A empresa de desenvolvimento retorna ao projeto de desenvolvimento de sistema para uma agência de viagens. Esse sistema precisa registrar pacotes de viagens e dados de uma venda. Cada pacote de viagens é formado pelo meio de transporte e pela hospedagem – cada meio de transporte tem tipo e valor e cada hospedagem tem tipo e valor. Os valores de pacote de viagem são formados pelos valores do transporte e da hospedagem somados a uma margem de lucro e taxas adicionais.
A venda inclui dados do cliente, forma de pagamento, data e pacote sendo vendido e precisa ser capaz de converter o valor do pacote em reais para dólar e vice-versa.
Sua tarefa será aplicar orientação a objetos para desenvolver um módulo em Java desse sistema.
 
Atividade
No NetBeans, crie um projeto Java (tipo console) com os seguintes itens:
*Classe para transporte, com o tipo (aéreo, rodoviário, marítimo etc.) e valor
*Classe para hospedagem, com descrição e valor de diária
*Classe para pacote de viagem, com transporte, hospedagem, destino (texto), quantidade de dias. Essa classe ainda deve ser capaz de
*calcular o total de hospedagem a partir do número de dias e o valor da diária.
*calcular valor de lucro a partir de uma margem informada (porcentagem) e valor informado. O resultado retornado deve ser o valor * margem aplicada ao valor.
*calcular e retornar o total do pacote, somando o transporte, o total da hospedagem e os valores adicionais informados – margem de lucro (porcentagem) e taxas adicionais (valor monetário).
*Observação: os valores nesta classe serão considerados em dólar.


Classe para venda, que contenha nome do cliente, forma de pagamento e pacote de viagem. A classe deve ser capaz de
converter um valor em reais a partir de um valor informado em dólar e da cotação da moeda, também informada.
mostrar na tela o total do pacote de viagem em dólar e em reais.


Na classe principal, elabore código para interação com o usuário em que seja possível “cadastrar” uma venda e
obtenha todos os valores necessários para criar um pacote de viagem e crie esse objeto.
mostre na tela as informações do pacote criado, incluindo o valor total. O usuário ainda precisará informar margem de lucro (uma porcentagem).
obtenha do usuário também as informações para a criação de uma venda.
mostre na tela todas as informações da venda, incluindo valor total em dólar e valor em reais (o usuário terá que informar a cotação do dólar no dia).
Recomenda-se o uso de construtores nas classes.*/