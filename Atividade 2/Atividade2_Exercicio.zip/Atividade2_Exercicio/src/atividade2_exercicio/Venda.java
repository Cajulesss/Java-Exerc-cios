/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividade2_exercicio;

/**
 *
 * @author GAMER
 */
public class Venda {
    private String nomeCliente;
    private String formaPagamento;
    private Pacote_Viagem pacoteViagem;
    private double valorEmDolar;
    private double valorEmReais;

    public Venda(String nomeCliente, String formaPagamento, Pacote_Viagem pacoteViagem) {
        this.nomeCliente = nomeCliente;
        this.formaPagamento = formaPagamento;
        this.pacoteViagem = pacoteViagem;
    }

    // Métodos para calcular o valor em dólar e em reais e mostrar na tela
    public void realizarVenda(double taxaCambio) {
        valorEmDolar = pacoteViagem.Conversao_moeda(taxaCambio);
        valorEmReais = valorEmDolar * taxaCambio;
        mostrarRecibo();
    }

    public void mostrarRecibo() {
        System.out.println("Nome do Cliente: " + nomeCliente);
        System.out.println("Forma de Pagamento: " + formaPagamento);
        System.out.println("Total do Pacote em Dólar: $" + valorEmDolar);
        System.out.println("Total do Pacote em Reais: R$ " + valorEmReais);
    }
}