/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package atividade2_exercicio;

/**
 *
 * @author GAMER
 */
public class Hospedagem {
    protected String Tipo_de_Quarto;
    public String Descricao_quarto;
    public double Valor_da_diaria;
    
    
    public void Status_Hospedagem(){
    
    System.out.println("Bem-Vindo ao sistema de diárias do Hotel! ");
    
    if(this.Tipo_de_Quarto.equalsIgnoreCase("Casal")){
        System.out.println("Quarto destinado a casais com uma única cama box, um sofá, TV com canais digitais e acesso gratuito a Netflix, contém uma janela que dá vista a cidade.");
    }
    
    }
}

    
